#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Creates unix aliases for scripts, copy this .githubScripts folder to your user's root
# directory, usually at ~/ (if you open up Terminal, you can do 'cd ~/' to get there).
# Put these lines at the end of your ~/.profile (without the '#') to run it on load:
# if [ -f ~/.githubScripts/aliases.sh ]; then
#	. ~/.githubScripts/aliases.sh
# fi

# cb - Create a branch with a pivotal story and human branch name
alias cb="~/.githubScripts/createBranch.sh"

# ub - Update a branch with commits from another branch using rebase,
#		mostly for updating your branch with the latest commits in
#		developed or your branch's parent.
alias ub="~/.githubScripts/updateBranch.sh"

# rb - Reset your branch to what's the latest in the remote repo's HEAD.
#		Only when you've royally effed up your local repo and want to reset.
alias rb="~/.githubScripts/resetBranch.sh"

# pb - Add all changes, commit them with message, and then push to remote repo.
alias pb="~/.githubScripts/pushBranch.sh"

# fb - Updates branch 2, then merges branch1 with branch2, with option to delete
#		branch1 locally and remotely, adds a finished commit messages to match
#		our PivotalTracker hook in Github, and pushes changes to remote repo.
alias fb="~/.githubScripts/finishBranch.sh"

# db - Delete a branch, with the option to delete the remote repo too
alias db="~/.githubScripts/deleteBranch.sh"

