#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Creates unix aliases for scripts, copy this .githubScripts folder to your user's root
# directory, usually at ~/ (if you open up Terminal, you can do 'cd ~/' to get there).
# Put these lines at the end of your ~/.profile (without the '#') to run it on load:
# if [ -f ~/.githubScripts/aliases.sh ]; then
#	. ~/.githubScripts/aliases.sh
# fi

alias gb="cat ~/.githubScripts/help.txt"

# gbc - Create a branch with a pivotal story and human branch name
alias gbc="~/.githubScripts/createBranch.sh"

# gbu - Update a branch with commits from another branch using rebase,
#		mostly for updating your branch with the latest commits in
#		developed or your branch's parent.
alias gbu="~/.githubScripts/updateBranch.sh"

# gbr - Reset your branch to what's the latest in the remote repo's HEAD.
#		Only when you've royally effed up your local repo and want to reset.
alias gbr="~/.githubScripts/resetBranch.sh"

# gbp - Add all changes, commit them with message, and then push to remote repo.
alias gbp="~/.githubScripts/pushBranch.sh"

# gbf - Updates branch 2, then merges branch1 with branch2, with option to delete
#		branch1 locally and remotely, adds a finished commit messages to match
#		our PivotalTracker hook in Github, and pushes changes to remote repo.
alias gbf="~/.githubScripts/finishBranch.sh"

# gbd - Delete a branch, with the option to delete the remote repo too
alias gbd="~/.githubScripts/deleteBranch.sh"

