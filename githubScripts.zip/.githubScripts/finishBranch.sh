#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Merges given branch into given branch name with finish message for Pivotal hook

# Early exit if any commands fail
set -e

# Check options
DELETEBRANCH=false
while getopts ":d" opt; do
	case $opt in
		d)
			echo " - Deleting branch $1." >&2;
			DELETEBRANCH=true;;
		\?)
			echo " - Invalid flag option: -$OPTARG" >&2;
			exit 1;;
	esac
done
shift $(( OPTIND - 1 ));	# Shift arguments by options

# Default branchname to development if not passed
UPDATEBRANCH="development"

# Check parameters
if [ -z "$1" ]; then	# If no parameters
	echo " - Usage: finishBranch [-d] branchToFinish branchToMergeInto
 - NOTE: Will discard any local changes that you have not committed!
	-d Delete finished branch locally and remote after merge."
	exit
fi
if [ -z "$2" ]; then	# If no second parameter
	echo " - Defaulting to development branch for merge."
else
	UPDATEBRANCH=$2
fi

# Checkout update branch & update it from remote
echo " - Updating $UPDATEBRANCH from remote"
git checkout "$UPDATEBRANCH" -f
git pull

# Check if there's a slash in the branch name for pivotal ID
echo " - Building merge commit string for $1"
if [[ "$1" == */* ]]; then
	# Put together pivotal finish message by parsing out ID#
	PIVOTALID=${1#*/}
	BRANCHNAME=${1%/*}
	MESSAGE="[finished #$PIVOTALID] - Branch $BRANCHNAME Finished"
else
	MESSAGE="Branch $1 Finished"
fi
echo "    "$MESSAGE

# Merge in finished branch
echo " - Merging $1 into $UPDATEBRANCH"
git merge --no-edit "$1"
git commit --amend -m "$MESSAGE"
git push

# Cleanup
if $DELETEBRANCH; then
	echo " - Deleting branches"
	git branch -D "$1"
	git push origin --delete "$1"
fi

echo "DONE"

