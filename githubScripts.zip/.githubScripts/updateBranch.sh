#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Updates the given git branch with updates from second
# given branch name using rebase.

# Early exit if any commands fail
set -e

# Default branchname to development if not passed
UPDATEBRANCH="development"

# Check parameters
if [ -z "$1" ]; then	# If no parameters
	echo " - Usage: updateBranch branchToBeUpdated branchToUpdateFrom
 - NOTE: Will discard any local changes that have not been committed!"
	exit
fi
if [ -z "$2" ]; then	# If no second parameter
	echo " - Defaulting to development branch for update."
else
	UPDATEBRANCH=$2
fi

# Checkout update branch & update it from remote
echo " - Updating $UPDATEBRANCH from remote"
git checkout "$UPDATEBRANCH" -f
git pull

# Go back to branch to update
echo " - Updating $1 from $UPDATEBRANCH"
git checkout "$1" -f
git rebase "$UPDATEBRANCH"


echo "DONE"

