#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Adds and commits and pushes all changes in a branch
# WARNING: will add all deleted files too

# Early exit if any commands fail
set -e

# Check parameters
if [ -z "$1" ]; then	# If no parameters
	echo ' - Usage: pushBranch "commitMessage"'
	exit
fi

# Add all changes
git add *
git add -u

# Commit and push
git commit -m "$1"
git push


echo "DONE"

