#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Resets branch to remote branch, discarding all changes.

# Early exit if any commands fail
set -e

# Check just in case
read -p " - Are you sure you want to reset your branch? (y/n) " -n 1
if [[ ! $REPLY =~ ^[Yy]$ ]]
then
	echo " - EXIT"
	exit
fi

# Fetch from remote and then do hard reset
git fetch origin
git reset --hard origin/HEAD


echo "DONE"

