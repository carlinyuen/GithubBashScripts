#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Creates a git branch using given name and pivotal number
# and sets up upstream tracking.

# Early exit if any commands fail
set -e

# Check options
DISCARDCHANGES=false
while getopts ":f" opt; do
	case $opt in
		f)
			echo " - Discarding local changes." >&2
			DISCARDCHANGES=true
			;;
		\?)
			echo " - Invalid flag option: -$OPTARG" >&2
			exit 1;
			;;
	esac
done
shift $(( OPTIND - 1 ));	# Shift arguments by options

# Check arguments
if [ -z "$1" ]; then	# If no parameters
	echo " - Usage: createBranch [-f] branchName pivotalStoryIDNumber
	-f Apply -f (force) flag to checkouts to discard local changes."
	exit
fi
if [ -n "$3" ]; then	# If there's a third parameter, probably a mistake
	echo " - No spaces for branch name please!"
	exit
fi

# Check that there's no slash in branch name
if [[ "$1" == */* ]]; then
	echo " - Branch name cannot have slashes in it!"
	exit
fi

# Setup branch name
BRANCHNAME="$1"
if [ -n "$2" ]; then	# If has pivotal story
	$BRANCHNAME="$1/$2"
fi

# Create local branch with given name
if $DISCARDCHANGES; then
	git checkout -b "$BRANCHNAME" -f
else
	git checkout -b "$BRANCHNAME"
fi

# Setup upstream tracking and push to remote
git push -u origin "$BRANCHNAME"

echo "DONE"

