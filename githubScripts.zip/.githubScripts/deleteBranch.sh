#!/bin/bash
# Written by Carlin Yuen, 2013.07.16
# Deletes a given branch, with the option to also delete the remote repo

# Early exit if any commands fail
set -e

# Check options
DELETEBRANCH=false
while getopts ":d" opt; do
	case $opt in
		d)
			echo " - Deleting remote branch $1 as well." >&2;
			DELETEBRANCH=true;;
		\?)
			echo " - Invalid flag option: -$OPTARG" >&2;
			exit 1;;
	esac
done
shift $(( OPTIND - 1 ));	# Shift arguments by options

# Check parameters
if [ -z "$1" ]; then	# If no parameters
	echo " - Usage: deleteBranch [-d] branchToDelete
	-d Delete remote branch too."
	exit
fi

# Delete
git branch -D "$1"
if $DELETEBRANCH; then
	echo " - Deleting remote branch"
	git push origin --delete "$1"
fi

echo "DONE"


